from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone
# Create your models here.

class Profile(models.Model):
    user = models.ForeignKey('auth.User')
    bio = models.TextField(blank = True)
    skills = models.CharField(max_length = 250, blank = True) #type student or teacher
    profile_image = models.ImageField(upload_to='static/', default='static/defaultProfile.jpg')
    email = models.CharField(max_length = 250)
    phoneNumber = models.CharField(max_length = 250)
    followers = models.IntegerField()

    @receiver(post_save, sender = User)
    def create_user_profile(sender, instance, created, **kwargs):
        if created:
            Profile.objects.created(user = instance)

    @receiver(post_save, sender = User)
    def save_user_profile(sender, instance, **kwargs):
        instance.profile.save()

    @receiver(post_save, sender = User)
    def delete_user_profile(sender, instance, **kwargs):
        instance.profile.delete()


class Project(models.Model):
    user = models.ForeignKey('auth.User')
    question = models.ForeignKey(Profile, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    text = models.TextField()
    published_date = models.DateTimeField(
            blank=True, null=True)
    project_image = models.ImageField(upload_to = 'static/', default = 'static/defaultProject.jpg')
    likes = models.IntegerField()
    dislikes = models.IntegerField()
    isPublic = models.BooleanField(initial = True)

    def publishProject(self):
        self.published_date = timezone.now()
        self.save()

    def __str__(self):
        return self.title