from django.db import models
from django.utils import timezone

# Create your models here.
class Questions(models.Model):
    user = models.ForeignKey('auth.User')
    title = models.CharField(max_length=200)
    details = models.TextField()
    published_date = models.DateTimeField(
            blank=True, null=True)
    question_image = models.ImageField(upload_to = 'static/', default = 'static/defaultProject.jpg')
    likes = models.IntegerField()
    dislikes = models.IntegerField()

    def publishProject(self):
        self.published_date = timezone.now()
        self.save()

    def __str__(self):
        return self.title


class Answers(models.Model):
    user = models.ForeignKey('auth.User')
    question = models.ForeignKey(Questions, on_delete = models.CASCADE)
    answer = models.TextField()
    published_date = models.DateTimeField(
        blank=True, null=True)