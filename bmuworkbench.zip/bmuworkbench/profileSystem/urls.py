from django.conf.urls import url
from . import views  # [.] represents current directory

urlpatterns = [
    url(r'^profile$', views.CreateProfile, name = 'Profile'),
    url(r'^$', views.Home, name= 'Home'),
    url(r'^updateProfile$', views.UpdateProfile, name='UpdateProfile'),
    url(r'profile/edit_profile', views.EditProfile, name='EditProfile'),
    url(r'profile/add_project', views.AddProject, name='AddProject'),
]