from django.shortcuts import render, get_object_or_404
from django.views.generic import CreateView
from django.contrib.auth import get_user
from .models import *
from django.http import HttpResponse
from django.utils import timezone
# Create your views here.

# def Profile(request):
#     # profile = Profile.objects.all()
#     return render(request, 'profile.html')
def Home(request):
    return HttpResponse("<h1>Welcome to BMU Workbench</h1>")

# def UpdateProfile(request):
def UpdateProfile(request):
    # if this is a POST request we need to process the form data
    # create a form instance and populate it with data from the request:
    form = ProfileForm(request.POST)
    if request.method == 'POST':
        # fields = ('user', 'name', 'kind', 'bio', 'skills', 'email', 'phoneNumber', 'profile_image')
        pro = form.save(commit=False)
        pro.user = request.user
        pro.save()
        profile = Profile.objects.filter(request.user)
        # check if it is valid
        if form.is_valid():
            return render(request, 'profile.html',{'profile' : profile})
    else:
        # form = ProfileForm()
        # profile = Profile.objects.filter(request.user)
        return HttpResponse("<h1>Not Saved</h1>")
        # return render(request, 'profile.html',{'form' : form})


def CreateProfile(request):
    profile = Profile.objects.all()
    project = Project.objects.all()
    return render(request, 'profile.html', {'profile': profile, 'project' : project})


def EditProfile(request):
    if request.method == "POST":
        instance = get_object_or_404(Profile, id = request.user.id)
        form = ProfileForm(request.POST or None, instance=instance)
        if form.is_valid():
            profile = form.save(commit=False)
            profile.user.id = request.user.id
            profile.save()
            pro = Profile.objects.all()
            project = Project.objects.all()
            return render(request, 'profile.html', {'profile' : pro,  'project' : project})
        # profile =  ProfileForm()
    else:
        profile = ProfileForm()
    return render(request,'edit_profile.html', {'profile' : profile})


def AddProject(request):
    project = None
    if request.method == "POST":
        form = ProjectForm(request.POST)
        if form.is_valid():
            project = form.save(commit=False)
            project.user.id = request.user.id
            project.save()
            return render(request, 'profile.html')
    else:
        project = ProjectForm()
    return render(request, 'add_project.html', {'project': project})

