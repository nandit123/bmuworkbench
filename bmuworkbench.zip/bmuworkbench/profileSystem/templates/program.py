n = int(input(''))
seriesLexico = []
for i in range(0, n):
    seriesLexico.append(input(''))
condition = input('').split()
key = int(condition[0])
series = []
if (condition[2] == 'numeric'):
    for i in range(0, n):
        series.append(seriesLexico[i].split())
        series = sorted(series, key=lambda x: int(x[key - 1]))
else:
    for i in range(0, n):
        series.append(seriesLexico[i].split())
        series = sorted(series, key=lambda x: x[key-1])
if(condition[1] == 'true'):
    for i in reversed(series):
        str1 = ' '.join(i)
        print(str1)
else:
    for i in series:
        str1 = ' '.join(i)
        print(str1)