import itertools
ll = [(1,2,3),(4,5,6)]
for item in itertools.chain.from_iterable(ll):
    print(item)