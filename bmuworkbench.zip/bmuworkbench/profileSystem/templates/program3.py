#!/bin/python3

import sys
from itertools import permutations
from fractions import gcd

# A utility function to check if a given node is leaf or not
def isLeaf(node):
    if node is None:
        return False
    if node.l is None and node.r is None:
        return True
    return False


# This function return sum of all left leaves in a
# given binary tree

def leftLeavesSum(root):
    # Initialize result
    res = 0
    # Update result if root is not None
    if root is not None:
        # If left of root is None, then add key of
        # left child
        if isLeaf(root):
            res += root.v
        else:
            # Else recur for left child of root
            res += leftLeavesSum(root.l)
            res += leftLeavesSum(root.r)


    return res


class Node:
    def __init__(self, val):
        self.l = None
        self.r = None
        self.v = val


class Tree:
    def __init__(self):
        self.root = None

    def getRoot(self):
        return self.root

    def add(self, val):
        if (self.root == None):
            self.root = Node(val)
        else:
            self._add(val, self.root)

    def _add(self, val, node):
        if (val < node.v):
            if (node.l != None):
                self._add(val, node.l)
            else:
                node.l = Node(val)
        else:
            if (node.r != None):
                self._add(val, node.r)
            else:
                node.r = Node(val)

    def find(self, val):
        if (self.root != None):
            return self._find(val, self.root)
        else:
            return None

    def _find(self, val, node):
        if (val == node.v):
            return node
        elif (val < node.v and node.l != None):
            self._find(val, node.l)
        elif (val > node.v and node.r != None):
            self._find(val, node.r)

    def deleteTree(self):
        # garbage collector will do this for us.
        self.root = None

    def printTree(self):
        if (self.root != None):
            self._printTree(self.root)

    def _printTree(self, node):
        if (node != None):
            self._printTree(node.l)
            print(str(node.v) + ' ')
            self._printTree(node.r)


def expectedAmount(a):
    tree = Tree()
    x = list(permutations(a))
    sum = 0
    for i in x:
        for j in i:
            tree.add(j)
            # tree.printTree()
        sum += leftLeavesSum(tree.getRoot())
        # print(sum)
        # print("********")
        tree.deleteTree()
    cases = x.__len__()
    z=gcd(sum, cases)
    sum = sum//z
    cases = cases//z
    if sum == cases:
        print(1)
    else:
        # print(str(sum)+"/"+str(cases))
        print(sum, end='/')
        print(cases)
# Complete this function



if __name__ == "__main__":
    t = int(input().strip())
    for a0 in range(t):
        n = int(input().strip())
        a = list(map(int, input().strip().split(' ')))
        expectedAmount(a)