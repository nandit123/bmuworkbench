from fractions import gcd
z= gcd(20,8)
print(z)
print(20//z)