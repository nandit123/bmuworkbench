if __name__ == "__main__":
    n = int(input())
    l = []
    for i in range(n):
        l.append(list(map(str, input().strip().split(' '))))
    condition = input('').split()
    key = int(condition[0])
    if (condition[2] == 'numeric'):
        series = sorted(l, key=lambda x: int(x[key - 1]))
    else:
        series = sorted(l, key=lambda x: x[key - 1])
    # rule = list(input().strip().split(' '))
    # result = sort(l, rule)
    if (condition[1] == 'true'):
        for i in reversed(series):
            str1 = ' '.join(i)
            print(str1)
    else:
        for i in series:
            str1 = ' '.join(i)
            print(str1)