#!/bin/python3

import sys
from itertools import permutations
from fractions import gcd

# function to check if a given node is leaf or not
def isLeaf(node):
    if node is None:
        return False
    if node.l is None and node.r is None:
        return True
    return False

# function return sum of all left leaves in a binary tree
def leftLeavesSum(root):
    res = 0
    if root is not None:
        if isLeaf(root):
            res += root.v
        else:
            res += leftLeavesSum(root.l)
            res += leftLeavesSum(root.r)
    return res


class Node:
    def __init__(self, val):
        self.l = None
        self.r = None
        self.v = val


class Tree:
    def __init__(self):
        self.root = None

    def getRoot(self):
        return self.root

    def add(self, val):
        if (self.root == None):
            self.root = Node(val)
        else:
            self._add(val, self.root)

    def _add(self, val, node):
        if (val < node.v):
            if (node.l != None):
                self._add(val, node.l)
            else:
                node.l = Node(val)
        else:
            if (node.r != None):
                self._add(val, node.r)
            else:
                node.r = Node(val)

    def deleteTree(self):
        self.root = None


def expectedAmount(a):
    tree = Tree()
    permutation = permutations(a)
    sum = 0
    cases = 0
    for i in permutation:
        cases += 1
        for j in i:
            tree.add(j)
        sum += leftLeavesSum(tree.getRoot())
        tree.deleteTree()
    sum += leftLeavesSum(tree.getRoot())
    tree.deleteTree()
    z=gcd(sum, cases)
    sum = sum//z
    cases = cases//z
    if sum == cases:
        print(1)
    else:
        print(sum, end='/')
        print(cases)
# Complete this function
if __name__ == "__main__":
    t = int(input().strip())
    for a0 in range(t):
        n = int(input().strip())
        a = list(map(int, input().strip().split(' ')))
        expectedAmount(a)