from django.apps import AppConfig


class ProfilesystemConfig(AppConfig):
    name = 'profileSystem'
