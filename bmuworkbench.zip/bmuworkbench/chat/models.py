from datetime import timezone
from django.db import models
# Create your models here.

class Sender_Chat(models.Model):
    sender = models.ForeignKey('auth.User')
    message = models.TextField(500)
    message_date = models.DateTimeField(
        blank=True, null=True)
    receiver = models.ForeignKey('auth.User.all()')


    def Send(self):
        self.message_date = timezone.now()
        self.save()